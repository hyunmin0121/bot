﻿import discord, aiofiles, emoji

intents = discord.Intents().all()
client = discord.Client(intents=intents)
prefix = '!'

@client.event
async def on_ready():
    print('ready')

@client.event
async def on_message(message):
    if message.content.startswith(f'{prefix}이모지설정'):
        if not message.author.guild_permissions.manage_guild:
            return

        msg = message.content.split(' ')[1]

        async with aiofiles.open('emoji/emoji', mode='w',encoding='utf-8') as f:
            await f.write(str(msg))
            await f.close()

        embed = discord.Embed(title=message.channel.guild.name, colour=discord.Colour(0x7289DA) , description='이모지 설정 완료')
        await message.channel.send(embed=embed)

    if message.content.startswith(f'{prefix}역할설정'):
        if not message.author.guild_permissions.manage_guild:
            return

        try:
            role = message.role_mentions[0].id
        except:
            return
        async with aiofiles.open('emoji/role', mode='w',encoding='utf-8') as f:
            await f.write(str(role))
            await f.close()
        
        embed = discord.Embed(title=message.channel.guild.name, colour=discord.Colour(0x7289DA) , description='역할 설정 완료')
        await message.channel.send(embed=embed)
            
    if message.content.startswith(f'{prefix}생성'):
        if not message.author.guild_permissions.manage_guild:
            return

        content = message.content[4:]
        # async with aiofiles.open('emoji/content', mode='r') as f:
        #     content = await f.read()

        async with aiofiles.open('emoji/emoji', mode='r',encoding='utf-8') as f:
            emoji = await f.read()

        async with aiofiles.open('emoji/role', mode='r',encoding='utf-8') as f:
            role = await f.read()
        
        await message.delete()
        if content == '':
            content = '내용을 입력해주세요.'
        else:
            content = content

        if role == '':
            return
        else:
            role = role
        
        if emoji == '':
            em = '✅'
        else:
            em = emoji

        embed = discord.Embed(title=message.channel.guild.name, colour=discord.Colour(0x7289DA) , description=content)
        add = await message.channel.send(embed=embed)
        await add.add_reaction(em)

        async with aiofiles.open('emoji/message', mode='w',encoding='utf-8') as f:
            await f.write(str(add.id))
            await f.close()

@client.event
async def on_raw_reaction_add(payload):
    if payload.member == client.user:
        return

    if not payload.guild_id == 843455491219652670:
        return

    print(payload)
    user = (payload.member)
    emg = (payload.emoji)
    msid = (payload.message_id)

    # print(user,emg,msid)

    async with aiofiles.open('emoji/message', mode='r',encoding='utf-8') as f:
        msg = await f.read()


    async with aiofiles.open('emoji/role', mode='r',encoding='utf-8') as f:
        role = await f.read()

    async with aiofiles.open('emoji/emoji', mode='r',encoding='utf-8') as f:
        emoji = await f.read()

    role = payload.member.guild.get_role(int(role))
    print(role)

    if not msid == int(msg):
        # print(1)
        return

    if str(emg) == str(emoji):
        await user.add_roles(role)

    message = await payload.member.guild.get_channel(payload.channel_id).fetch_message(msid)
    await message.remove_reaction(emg, user)


client.run('토큰')
